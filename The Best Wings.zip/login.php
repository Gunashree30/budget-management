
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login </title>
    <link rel="stylesheet" href="Css/style.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap"
      rel="stylesheet" />
  </head>
  <body>
  <center>
  <div class="bg">
  <form action="home.php" method="POST">
    <div class="login-box">
      <h1>Login</h1>
      <form>
        <label>Email</label>
        <input type="email" placeholder="" required />
        <label>Password</label>
        <input type="password" placeholder="" required />
        <input type="Submit" />
      <closeform></closeform></form>
    </div>
    <p class="para-2">
      Not have an account? <a href="reg.php">Sign Up Here</a>
    </p>
	</center>
	</div>
  </body>
</html>



<style>
body {
  background-color: #344a72;
  font-family: "Roboto", sans-serif;
}

.signup-box {
  width: 360px;
  height: 620px;
  margin: 10px;
  background-color: white;
  border-radius: 3px;
}


h1 {
  text-align: center;
  padding-top: 15px;
}

h4 {
  text-align: center;
}

form {
  width: 300px;
  margin-left: 20px;
}

form label {
  display: flex;
  margin-top: 200px;
  font-size: 20px;
}

form input {
  width: 100%;
  padding: 7px;
  border: none;
  border: 1px solid gray;
  border-radius: 100px;
  outline: none;
}
input[type="button"] {
  width: 320px;
  height: 10px;
  margin-top: 200px;
  border: none;
  background-color: #49c1a2;
  color: white;
  font-size: 18px;
}
p {
  text-align: center;
  padding-top: 100px;
  font-size: 15px;
}
.para-2 {
  text-align: center;
  color: black;
  font-size: 15px;
  margin-top: 10px;
}
.para-2 a {
  color: #49c1a2;
}
.bg {
  /* The image used */
  background-image:url("logimage.jpg");

  /* Full height */
  height: 105%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

</style>