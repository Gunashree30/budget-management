<!DOCTYPE html>
<html lang="en">
  <head>
    <title> form alignment </title>
	<style type="text/css">
	
	label{
		width: 150px;
		display:inline-block;
		margin:50px;

	}
	#form{
		border-radius:200px;
		background:white;
		color:white;
		width:500px;
		padding:50px;
	}
	h2{
		text-align:center;
	}
	#submit{
		width:20%;
		margin-top:4px;
	}
	</style>
  </head>
  <body>
  <div class="bg">
  <center>
  <form action="login.php" method="post">
   
      <h2>Sign Up</h2>
      <h4>It's free and only takes a minute</h4>
      <form>
        <label>FIRST NAME</label>
        <input type="text" placeholder="" id="firstName" name="firstName" required /><br>
        <label>LAST NAME</label>
        <input type="text" placeholder="" id="lastName" name="lastName" /><br>
        <label>EMAIL</label>
        <input type="email" placeholder="" id="email" name="email" required /><br>
        <label>PASSWORD</label>
        <input type="password" placeholder="" id="password" name="password" required /><br>
        <label>CONFIRM PASSWORD</label>
        <input type="password" placeholder="" id="cpassword" name="cpassword" required /><br>
        <input type="Submit" name="submit" id="submit"/>
      <closeform></closeform></form>
     </div>
    </div>
	<center>
    <p>
      Already have an account? <a href="login.php">Login here</a>
    </p>
	</center>
	</form>
	</center>
  </body>
</html>
<style>
.bg {
  /* The image used */
  background-image:url("reg2image.jpg");

  /* Full height */
  height: 105%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>


