<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Home page</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<link rel="stylesheet" href="homestyle.css" >
</head>
<body>

<div class="bg">
	<form action='' method="POST">
		<div class="m">
			<a href="reg.php">
				<button type="button" style="background-color: purple color: white;margin-top:6px;padding: 5px 12px;text-align: center;font-size: 16px;" class="floated" id="slide_stop_button">
				<strong>register</strong></button></a>
				<a href="ind.php">
				<button type="button" style=" background-color:purple /* Green */color: white;margin-top:6px;padding: 5px 12px;text-align: center;font-size: 16px;" class="floated" id="slide_start_button">
				<strong>budget management</strong></button></a>
				<a href="expense.html">
				<button type="button" style=" background-color:purple /* Green */color: white;margin-top:6px;padding: 5px 12px;text-align: center;font-size: 16px;" class="floated" id="slide_start_button">
				<strong>expense tracker</strong></button></a>
				<button type="button" style=" background-color:purple /* Green */color: white;margin-top:6px;padding: 5px 12px;text-align: center;font-size: 16px;" class="floated" id="slide_start_button">
				<strong>about</strong></button>
		</div>
		<div class="font">
			<h1><center>Home</center></h1>
		</div>
	</form>
</div>
</body>
</html>
