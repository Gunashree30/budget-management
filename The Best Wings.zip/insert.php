<?php
include "dbconfig.php";
$firstName=$_POST['firstName'];
$lastName=$_POST['lastName'];
$email=$_POST['email'];
$password=$_POST['password'];
$sql="insert into register(firstName,lastName,email,password)values('$firstName','$lastName',$email','$password')";
if(mysqli_query($conn,$sql))
{
	echo "insert success";
	echo '<script> alert("insert done") </script>';
	header('refresh:1,url=login.php');
}
else{
	echo "failure";
}
mysqli_close($conn);
?>