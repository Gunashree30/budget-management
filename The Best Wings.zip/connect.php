<?php
    $firstName= $_POST['firstName'];
	$lastName= $_POST['lastName'];
    $email= $_POST['email'];
	$password= $_POST['password'];
	$cpassword= $_POST['cpassword'];
	//database connection 
	$conn= new mysqli('localhost','root','','expensetracking');
	if($conn->connect_error){
		die('connection failed :' .$conn->connect_error);
	}else{
		$stmt=$conn->prepare("insert into register(firstName, lastName, email, password, cpassword)
		values(?,?,?,?,?)");
		$stmt->bind_param("sssss",$firstName ,$lastName ,$email, $password, $cpassword);
		$stmt->execute();
		echo "registration succussfull";
		$stmt->close();
		$conn->close();
	}
	
?>